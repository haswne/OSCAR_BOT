Parse tl scheme to tlo file. Formely part of telegram-cli
